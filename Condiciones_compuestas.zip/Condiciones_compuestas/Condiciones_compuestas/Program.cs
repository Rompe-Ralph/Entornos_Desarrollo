﻿using System;
/**************************************
 * Autor: Salvador Cintado Torres
 * Curso: 1DAM
 * Asignación: Actividad 1 Condiciones Compuestas
 * Fecha de asignación: 25/03/2020
 *************************************/

namespace Condiciones_compuestas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce un mes: ");
            String mes = Console.ReadLine();//Aqui declaro la variable mes

            if (mes == "enero" || mes == "febrero" || mes == "marzo") //Aqui es para que if sepa que 'mes' tienen que ser los que estan dentro de los parentesis
            {
                Console.WriteLine("El mes " + mes + " pertenece al primer trimestre.");
            }
            else  
            {   
                Console.WriteLine("El mes que has introducido pertenece al segundo o tercer trimestre."); //Esta opcion la he puesto si en el caso que no sea del primer timestre salga esta opción
            }
        }
    }
}
