﻿using System;

namespace Condiciones_compuestas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce un mes: ");
            String mes = Console.ReadLine();

            if (mes == "enero" || mes == "febrero" || mes == "marzo")
            {
                Console.WriteLine("El mes " + mes + " pertenece al primer trimestre del AÃ±o. ");
            }
        }
    }
}
