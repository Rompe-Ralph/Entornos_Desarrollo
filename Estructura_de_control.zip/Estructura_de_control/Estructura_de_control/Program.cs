﻿using System;
/**************************************
 * Autor: Salvador Cintado Torres
 * Curso: 1DAM
 * Asignación: Actividad 2 Estructura de control
 * Fecha de asignación: 25/03/2020
 *************************************/
namespace Estructura_de_control
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int contador = 0;
            int mul = 1;
            Console.WriteLine("Introduce cuántos Números quieres: ");
            numero = int.Parse(Console.ReadLine());
            Random random = new Random(); //Es una clase de sistema que el cual genera numero aleatorios
            Console.WriteLine("Los números aleatorios son:");
            for (int i = 0; i < numero; i++)
            {
                int randomNumber = random.Next(0, 100);//Se generan los numeros aleatorios del 0 a 100
                Console.WriteLine(randomNumber);
                if ((randomNumber % 2) == 0)//Aqui comprobamos que si el numero aleatorio al dividirlo entre 2 da 0 es par
                {
                    Console.WriteLine("Es Par");
                    contador++;
                }
                else
                {
                    Console.WriteLine("Es Impar");
                }

                for (int j = 1; j <= contador; j++)
                {
                    mul = mul * (j * 2);
                }
                Console.WriteLine("Han salido: " + contador + " numeros pares.");
                Console.WriteLine("La multiplicacion de los " + contador + " primeros números pares es: " + mul);
            }
        }
    }
}