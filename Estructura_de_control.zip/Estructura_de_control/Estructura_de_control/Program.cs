﻿using System;

namespace Estructura_de_control
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;
            int contador = 0;
            int mul = 1;
            Console.WriteLine("Introduce cuántos Números quieres generar");
            number = int.Parse(Console.ReadLine());
            Random random = new Random();
            Console.WriteLine("Los números aleatorios son:");
            for (int i = 0; i < number; i++)
            {
                int randomNumber = random.Next(0, 100);
                Console.WriteLine(randomNumber);
                if ((randomNumber % 2) == 0)
                {
                    Console.WriteLine("Es Par");
                    contador++;
                }
                else { }
                Console.WriteLine("Es Impar");
            }

            for (int i = 1; i <= contador; i++)
            {
                mul = mul * (i * 2);
            }
            Console.WriteLine("Han salido: " + contador + " numeros pares.");
            Console.WriteLine("La multiplicacion de los " + contador + " primeros números pares es: " + mul);
        }
    }
}