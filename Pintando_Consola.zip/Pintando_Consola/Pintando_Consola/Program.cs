﻿using System;
/**************************************
 * Autor: Salvador Cintado Torres
 * Curso: 1DAM
 * Asignación: Actividad 5 Pintando Consolas
 * Fecha de asignación: 25/03/2020
 *************************************/
namespace Pintando_Consola
{
    class Program
    {
        protected static int origRow;
        protected static int origCol;

        
        public static void Main()
        {
            // Obtenga una matriz con los valores de los miembros de enumeración ConsoleColor.
            ConsoleColor[] colors = (ConsoleColor[])ConsoleColor.GetValues(typeof(ConsoleColor));
            // Guarda el fondo actual y los colores de primer plano.
            ConsoleColor currentBackground = Console.BackgroundColor;
            ConsoleColor currentForeground = Console.ForegroundColor;

            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;


            for (int j = 0; j < 3000; j++)
            {
                WriteAt(colors);
            }

            Console.SetCursorPosition(origCol + 81, origRow + 25);// Para poner el cursor al final y salga el mensaje de fin de programa
            Console.ResetColor();

        }

        protected static void WriteAt(ConsoleColor[] colors)
        {
            try
            {
                Random random = new Random();
                int aleatorioCaracter = random.Next(5);
                char[] carac = { (char)33, (char)34, (char)35, (char)36, (char)37 };

                int colorCaracter = random.Next(16);//Aqui se genera los colores de los caracteres aleatoriamente

                int colorCaracterFondo = random.Next(16);//Aqui se genera los colores del fondo aleatoriamente

                int posX = random.Next(81);
                int posY = random.Next(25);

                Console.SetCursorPosition(origCol + posX, origRow + posY);// Posiciones de la consola donde se imprime             
                Console.ForegroundColor = colors[colorCaracter];// Color del caracter
                Console.BackgroundColor = colors[colorCaracterFondo];// Color del fondo
                Console.Write(carac[aleatorioCaracter]);// Visión del caracter aleatorio del array

            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.Clear();
                Console.WriteLine(e.Message);
            }
        }




    }
}