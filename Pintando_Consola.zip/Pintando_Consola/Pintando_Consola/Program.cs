﻿using System;

namespace Pintando_Consola
{
    class Program
    {
        protected static int origRow;
        protected static int origCol;

        protected static void WriteAt(ConsoleColor[] colors)
        {
            try
            {
                Random ran = new Random();
                int aleatorioCaracter = ran.Next(5);
                char[] carac = { (char)33, (char)34, (char)35, (char)36, (char)37 };

                int colorCaracter = ran.Next(16);//Total colores hay 14 colores distintos

                int colorCaracterFondo = ran.Next(16);

                int posX = ran.Next(81);
                int posY = ran.Next(25);

                Console.SetCursorPosition(origCol + posX, origRow + posY);//posiciones de la consola donde se imprime             
                Console.ForegroundColor = colors[colorCaracter];//color del caracter
                Console.BackgroundColor = colors[colorCaracterFondo];//color del fondo
                Console.Write(carac[aleatorioCaracter]);//Impresion del caracter aleatorio del array

            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.Clear();
                Console.WriteLine(e.Message);
            }
        }


        public static void Main()
        {
            // Get an array with the values of ConsoleColor enumeration members.
            ConsoleColor[] colors = (ConsoleColor[])ConsoleColor.GetValues(typeof(ConsoleColor));
            // Save the current background and foreground colors.
            ConsoleColor currentBackground = Console.BackgroundColor;
            ConsoleColor currentForeground = Console.ForegroundColor;

            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;


            for (int j = 0; j < 3000; j++)
            {
                WriteAt(colors);
            }

            Console.SetCursorPosition(origCol + 81, origRow + 25);//Para poner el cursor al final y que el mensaje de fin de programa si que salga al final
            Console.ResetColor();

        }


    }
}