﻿using System;

namespace TryCatch_Finally
{
    class Program
    {
        static void Main(string[] args)
        {
            //LecturaFichero
            int counter = 0;
            string line;

            // Read the file and display it line by line.
            System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\cenec\Desktop\pc523despues.txt");
            try
            {


                while ((line = file.ReadLine()) != null)
                {
                    System.Console.WriteLine(line);
                    counter++;
                }

                file.Close();
            }
            catch (Exception e)
            {
                file.Close();
                Environment.Exit(99);
            }

            System.Console.WriteLine("There were {0} lines.", counter);



            //OrdenarArray
            byte[] numeros = new byte[10];
            Boolean correcto = true;

            for (int i = 0; i < numeros.Length; i++)
            {
                while (correcto)
                {
                    try
                    {
                        do
                        {
                            Console.WriteLine("");
                            Console.WriteLine("Introduzca el " + (i + 1) + "Âº" + "numero que quiera(Son diez en total y entre el 1 y 99)");
                            numeros[i] = byte.Parse(Console.ReadLine());
                            correcto = false;
                        } while (!(numeros[i] < 100 && numeros[i] > 0));
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("");
                        Console.WriteLine("Debe introducir un numero(no una letra)\n");
                        Console.WriteLine(e);
                        correcto = true;
                    }

                }
                correcto = true;
            }

            Console.WriteLine("");
            Console.WriteLine("El array ordenado es:");
            Array.Sort(numeros);

            for (int i = 0; i < numeros.Length; i++)
            {
                Console.WriteLine(numeros[i]);
            }
        }
    }
}
