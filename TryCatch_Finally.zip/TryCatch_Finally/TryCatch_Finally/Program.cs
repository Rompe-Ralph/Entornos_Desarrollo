﻿using System;
/**************************************
 * Autor: Salvador Cintado Torres
 * Curso: 1DAM
 * Asignación: Actividad 4 TryCatch_Finally
 * Fecha de asignación: 25/03/2020
 *************************************/
namespace TryCatch_Finally
{
    class Program
    {
        static void Main(string[] args)
        {
            int contador = 0;
            String linea;
            String ruta = "C:/Users/salva/OneDrive/Escritorio/Ciclo_Formativo_Superior_1DAM/Entorno_de_Desarrollo/Segundo_Trimestre/ejemplo.txt"; //Aqui deberemos poner la ruta del archivo que usaremos
            System.IO.StreamReader file = new System.IO.StreamReader(ruta);
            //En el try comprobamos si en el documento de ejemplo hay alguna linea de texto en el caso de que no la haya saltara un error
            try
            {
                while ((linea = file.ReadLine()) !=null)
                {
                    System.Console.WriteLine(linea);
                    contador++;
                }
                file.Close();
            }
            catch(System.IO.IOException e)
            {
                Console.WriteLine("Error de lectura desde {0}. Message = {1}", ruta, e.Message);
            }
            finally
            {
                if(file != null)
                {
                    file.Close();//Aqui se cerrara el archivo de texto en el caso de que de error
                }
                System.Console.WriteLine("There were {0} lines.", contador); //Aqui muestra las lineas que tiene el documento de txt
                System.Console.ReadLine();
            }
        }

    }
}
