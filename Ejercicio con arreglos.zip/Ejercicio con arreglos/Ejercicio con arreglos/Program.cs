﻿using System;

namespace Ejercicio_con_arreglos
{ 

    class Program
    {
        public enum dias
        {
            Lunes = 0,
            Martes = 1,
            Miercoles = 2,
            Jueves = 3,
            Viernes = 4,
            Sabado = 5,
            Domingo = 6,
        }
        static void Main(string[] args)
        {
            string[] dias = { "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo" };
            int[] h = {4, 4, 4, 4, 6, 0, 0};

            Console.WriteLine("EJERCICIO CON ARREGLOS");

            Console.WriteLine("¿De que dias quieres comprobar las horas?");
            string l = Console.ReadLine();
            int dia = int.Parse(l);
            dia = dia - 1;
            dias x = (dias)dia;

            if (dia <= 6 && dia >= 0)
            {
                Console.WriteLine("\nDias: " +x+ "\nHoras trabajadas: "+h[dia]);

            }
            else
            {
                Console.WriteLine("Introduce un dia de la semana correcto");
            }

        }
    }
}
