﻿using System;

namespace Operación_Matemática
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isNumeric = true;
            String texto;
            float num1;

            Console.WriteLine("Introduzca un numero");
            texto = Console.ReadLine();
            isNumeric = float.TryParse(texto, out num1);

            if (!isNumeric)
            {
                Console.WriteLine("ERROR.No es un numero");
                System.Environment.Exit(404);
            }


            isNumeric = true;
            float num2;
            Console.WriteLine("Introduzca otro numero,asegurese que es otro numero");
            texto = Console.ReadLine();
            isNumeric = float.TryParse(texto, out num2);

            if (!isNumeric)
            {
                Console.WriteLine("ERROR.No es un numero");
                System.Environment.Exit(404);
            }

            Console.WriteLine("Introduzca el operador");
            char signo = char.Parse(Console.ReadLine());


            switch (signo)
            {
                case '+':
                    Console.WriteLine("La solucion es:\n" + num1 + "+" + num2 + "=" + (num1 + num2));
                    break;

                case '-':
                    Console.WriteLine("La solucion es:\n" + num1 + "-" + num2 + "=" + (num1 - num2));
                    break;

                case '*':
                    Console.WriteLine("La solucion es:\n" + num1 + "*" + num2 + "=" + (num1 * num2));
                    break;

                case '/':
                    Console.WriteLine("La solucion es:\n" + num1 + "/" + num2 + "=" + (num1 / num2));
                    break;

                case '%':
                    Console.WriteLine("La solucion es:\n" + num1 + "%" + num2 + "=" + (num1 % num2));
                    break;

                default:
                    Console.WriteLine("Operador no valido");
                    System.Environment.Exit(505);
                    break;
            }

        }
    }
}
