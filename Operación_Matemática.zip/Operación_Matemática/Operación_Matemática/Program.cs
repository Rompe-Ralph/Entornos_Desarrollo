﻿using System;
/**************************************
 * Autor: Salvador Cintado Torres
 * Curso: 1DAM
 * Asignación: Actividad 3 Operacion_Matemática
 * Fecha de asignación: 25/03/2020
 *************************************/
namespace Operación_Matemática
{
    class Program
    {
        static void Main(string[] args)
        {
            bool numero = true;
            String texto;

            //Primer Numero
            float num1; 
            Console.WriteLine("Introduzca un numero");
            texto = Console.ReadLine();
            numero = float.TryParse(texto, out num1);

            if (!numero)
            {
                Console.WriteLine("No es un numero");
                Console.WriteLine("Vuelva a intentarlo");

            }

            numero = true;
            //Segundo Numero
            float num2; 
            Console.WriteLine("Introduzca otro numero,asegurese de que no sea igual al primer numero");
            texto = Console.ReadLine();
            numero = float.TryParse(texto, out num2);

            if (!numero) //En este caso sera error en el programa en el caso de sea letra 
            {
                Console.WriteLine("No es un numero");
                Console.WriteLine("Vuelva a intentarlo");
            }

            //Aqui se introduce el operador
            Console.WriteLine("Introduzca el operador");
            char signo = char.Parse(Console.ReadLine());

            //Este switch indentica el operador que hayas intruducido 
            switch (signo)
            {
                case '+':
                    Console.WriteLine("La solucion es:\n" + num1 + "+" + num2 + "=" + (num1 + num2));
                    break;

                case '-':
                    Console.WriteLine("La solucion es:\n" + num1 + "-" + num2 + "=" + (num1 - num2));
                    break;

                case '*':
                    Console.WriteLine("La solucion es:\n" + num1 + "*" + num2 + "=" + (num1 * num2));
                    break;

                case '/':
                    Console.WriteLine("La solucion es:\n" + num1 + "/" + num2 + "=" + (num1 / num2));
                    break;

                case '%':
                    Console.WriteLine("La solucion es:\n" + num1 + "%" + num2 + "=" + (num1 % num2));
                    break;

                default:
                    Console.WriteLine("Operador no valido");                  
                    break;
            }

        }
    }
}
